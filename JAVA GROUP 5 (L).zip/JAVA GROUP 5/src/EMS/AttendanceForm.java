package EMS;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 * Single-class workflow for Attendance.
 * Fixed: Updated AttendanceRecord constructor call to include Full Name.
 */
public class AttendanceForm {

    private Stage stage;
    private String verifiedEmployeeId = null;
    private ToggleGroup[] dayGroups = new ToggleGroup[22];

    public AttendanceForm(Stage stage) {
        this.stage = stage;
    }

    public void show() {
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #F4F7F6;");

        // --- 1. ID LOGIN SECTION ---
        VBox topSection = new VBox(15);
        topSection.setAlignment(Pos.CENTER);
        topSection.setPadding(new Insets(0, 0, 20, 0));

        Label title = new Label("EMPLOYEE ATTENDANCE LOGIN");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 20));

        TextField idField = new TextField();
        idField.setPromptText("Enter Employee ID");
        idField.setMaxWidth(250);
        idField.setStyle("-fx-padding: 10; -fx-border-color: #DCDDE1; -fx-border-radius: 5;");

        Button btnVerify = new Button("Verify & Access Form");
        btnVerify.setPrefWidth(250);
        btnVerify.setStyle("-fx-background-color: #2980B9; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10;");

        Label statusMsg = new Label("Grid locked. Please enter a valid ID.");
        statusMsg.setStyle("-fx-text-fill: #7F8C8D;");

        topSection.getChildren().addAll(title, idField, btnVerify, statusMsg, new Separator());

        // --- 2. 22-DAY ATTENDANCE GRID ---
        GridPane grid = new GridPane();
        grid.setHgap(30);
        grid.setVgap(10);
        grid.setAlignment(Pos.CENTER);
        grid.setDisable(true); 

        grid.addRow(0, new Label("Day #"), new Label("Present"), new Label("Absent"));

        for (int i = 0; i < 22; i++) {
            final int currentIndex = i; 
            dayGroups[i] = new ToggleGroup();
            
            RadioButton rbPresent = new RadioButton();
            rbPresent.setToggleGroup(dayGroups[i]);
            rbPresent.setUserData("P");
            
            RadioButton rbAbsent = new RadioButton();
            rbAbsent.setToggleGroup(dayGroups[i]);
            rbAbsent.setUserData("A");
            rbAbsent.setSelected(true); 

            // LOGIC: Ensure only one day can be "Present" at a time
            dayGroups[i].selectedToggleProperty().addListener((obs, oldT, newT) -> {
                if (newT != null && "P".equals(newT.getUserData())) {
                    for (int j = 0; j < 22; j++) {
                        if (j != currentIndex) {
                            RadioButton otherAbsent = (RadioButton) dayGroups[j].getToggles().get(1);
                            otherAbsent.setSelected(true);
                        }
                    }
                }
            });

            grid.addRow(i + 1, new Label("Day " + (i + 1)), rbPresent, rbAbsent);
        }

        ScrollPane scrollPane = new ScrollPane(grid);
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefHeight(350);

        // --- 3. SUBMISSION & NAVIGATION SECTION ---
        VBox footer = new VBox(10);
        footer.setAlignment(Pos.CENTER);
        footer.setPadding(new Insets(20, 0, 0, 0));

        Button btnSubmit = new Button("SUBMIT ATTENDANCE");
        btnSubmit.setDisable(true); 
        btnSubmit.setPrefWidth(350);
        btnSubmit.setStyle("-fx-background-color: #27AE60; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 12;");

        Button btnBackToLogin = new Button("Back to Login Form");
        btnBackToLogin.setPrefWidth(350);
        btnBackToLogin.setStyle("-fx-background-color: #7F8C8D; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10;");

        // --- LOGIC: Verification with Role Check ---
        btnVerify.setOnAction(e -> {
            String inputId = idField.getText().trim();
            Employee emp = EmployeeRecordsModule.getEmployeeById(inputId);
            
            if (emp != null && "Employee".equalsIgnoreCase(emp.getRole())) {
                verifiedEmployeeId = inputId;
                statusMsg.setText("✓ ID Verified: " + verifiedEmployeeId);
                statusMsg.setStyle("-fx-text-fill: #27AE60; -fx-font-weight: bold;");
                
                grid.setDisable(false); 
                btnSubmit.setDisable(false); 
                idField.setEditable(false); 
            } 
            else if (emp != null && "Admin".equalsIgnoreCase(emp.getRole())) {
                new Alert(Alert.AlertType.ERROR, "Access Denied: Admin IDs cannot use the Employee Attendance Form.").show();
            } 
            else {
                new Alert(Alert.AlertType.ERROR, "ID not found! Please check your ID and try again.").show();
            }
        });

        // Submit Logic: Saves data to database then logs out
        btnSubmit.setOnAction(e -> {
            int presentCount = 0;
            for (int i = 0; i < 22; i++) {
                if ("P".equals(dayGroups[i].getSelectedToggle().getUserData())) {
                    presentCount++;
                }
            }

            // Record value automatically in the database
            ManageAttendance.recordAttendanceToDatabase(verifiedEmployeeId, presentCount, 0);

            // --- FIXED: Update local memory list with Name lookup ---
            ManageAttendance.AttendanceRecord record = ManageAttendance.getAttendanceById(verifiedEmployeeId);
            if (record != null) {
                record.setDaysPresent(presentCount);
            } else {
                // Fetch the name from the module to satisfy the constructor
                Employee emp = EmployeeRecordsModule.getEmployeeById(verifiedEmployeeId);
                String fullName = (emp != null) ? emp.getName() : "Unknown Employee";
                
                // Fixed constructor call: (ID, Name, Count)
                ManageAttendance.attendanceList.add(new ManageAttendance.AttendanceRecord(verifiedEmployeeId, fullName, presentCount));
            }

            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("Success");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Attendance logged for ID: " + verifiedEmployeeId + "\nReturning to Login Form.");
            successAlert.showAndWait();

            // Security Logout
            new LoginController().showLogin(stage);
        });

        btnBackToLogin.setOnAction(e -> new LoginController().showLogin(stage));

        footer.getChildren().addAll(btnSubmit, btnBackToLogin);

        root.setTop(topSection);
        root.setCenter(scrollPane);
        root.setBottom(footer);

        Scene scene = new Scene(root, 500, 750);
        stage.setTitle("EMS - Attendance Submission");
        stage.setScene(scene);
        stage.show();
    }
}