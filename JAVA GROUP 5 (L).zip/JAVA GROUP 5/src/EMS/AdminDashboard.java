package EMS;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class AdminDashboard {

    private Stage stage;
    private String adminName;

    public AdminDashboard(Stage stage, String adminName) {
        this.stage = stage;
        this.adminName = adminName;
    }

    public void show() {
        BorderPane mainLayout = new BorderPane();
        mainLayout.setStyle("-fx-background-color: #F4F7F6;");

        // --- 1. TOP HEADER WITH LOGOS ---
        HBox header = new HBox(20);
        header.setPadding(new Insets(10, 25, 10, 25));
        header.setAlignment(Pos.CENTER);
        // Using Woldiya University Deep Green for the Admin header
        header.setStyle("-fx-background-color: #1A237E; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 10, 0, 0, 0);"); 
        
        // Left Logo: Woldiya University
        ImageView leftLogo = new ImageView();
        try {
            leftLogo.setImage(new Image(getClass().getResourceAsStream("/logincontroller/Woldiya-University.png")));
            leftLogo.setFitHeight(70);
            leftLogo.setPreserveRatio(true);
        } catch (Exception e) { System.out.println("Left logo not found"); }

        // Dashboard Title
        Label title = new Label("ADMIN CONTROL PANEL - EMS");
        title.setTextFill(Color.WHITE);
        title.setFont(Font.font("Arial", FontWeight.BOLD, 22));
        
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        
        // Admin Greeting
        Label userLabel = new Label("System Admin: " + adminName);
        userLabel.setTextFill(Color.WHITE);
        userLabel.setFont(Font.font("Arial", FontWeight.MEDIUM, 14));

        // Right Logo: WDU
        ImageView rightLogo = new ImageView();
        try {
            rightLogo.setImage(new Image(getClass().getResourceAsStream("/logincontroller/WDU.jpg")));
            rightLogo.setFitHeight(70);
            rightLogo.setPreserveRatio(true);
        } catch (Exception e) { System.out.println("Right logo not found"); }

        // Assemble Header: [Left Logo] [Title] [Spacer] [Admin Info] [Right Logo]
        header.getChildren().addAll(leftLogo, title, spacer, userLabel, rightLogo);

        // --- 2. CENTER GRID ---
        GridPane dashboardGrid = new GridPane();
        dashboardGrid.setHgap(30);
        dashboardGrid.setVgap(30);
        dashboardGrid.setAlignment(Pos.CENTER);
        dashboardGrid.setPadding(new Insets(40));

        // Define Cards
        VBox card1 = createFunctionalCard("Employee Records", "Manage staff profiles.", "#3498DB");
        VBox card2 = createFunctionalCard("Manage Attendance", "Monitor check-ins.", "#27AE60");
        VBox card3 = createFunctionalCard("Leave Management", "Review requests.", "#8E44AD");
        VBox card4 = createFunctionalCard("Salary Management", "Process salaries.", "#E67E22");
        VBox card5 = createFunctionalCard("Reporting", "Audit logs.", "#E74C3C");
        VBox card6 = createFunctionalCard("User Management", "Manage accounts.", "#95A5A6");

        // Action Linking
        ((Button) card1.getChildren().get(2)).setOnAction(e -> new EmployeeRecordsModule(stage).show());
        ((Button) card2.getChildren().get(2)).setOnAction(e -> new ManageAttendance(stage).show());
        ((Button) card3.getChildren().get(2)).setOnAction(e -> new LeaveManagement(stage).show());
        ((Button) card4.getChildren().get(2)).setOnAction(e -> new SalaryManagement(stage).show());
        ((Button) card5.getChildren().get(2)).setOnAction(e -> new ReportingModule(stage).show());
        ((Button) card6.getChildren().get(2)).setOnAction(e -> new UserAccountManagementModule(stage).show());

        // Add to Grid
        dashboardGrid.add(card1, 0, 0); 
        dashboardGrid.add(card2, 1, 0); 
        dashboardGrid.add(card3, 2, 0); 
        dashboardGrid.add(card4, 0, 1); 
        dashboardGrid.add(card5, 1, 1);
        dashboardGrid.add(card6, 2, 1); 

        // --- 3. BOTTOM FOOTER ---
        HBox footer = new HBox();
        footer.setPadding(new Insets(20, 40, 30, 40));
        footer.setAlignment(Pos.CENTER);

        Button btnLogout = new Button("LOGOUT & EXIT TO LOGIN");
        btnLogout.setPrefSize(250, 40);
        btnLogout.setStyle("-fx-background-color: #C0392B; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 14px; -fx-cursor: hand; -fx-background-radius: 20;");
        
        btnLogout.setOnAction(e -> new LoginController().showLogin(stage));

        btnLogout.setOnMouseEntered(e -> btnLogout.setStyle("-fx-background-color: #E74C3C; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 14px; -fx-cursor: hand; -fx-background-radius: 20;"));
        btnLogout.setOnMouseExited(e -> btnLogout.setStyle("-fx-background-color: #C0392B; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 14px; -fx-cursor: hand; -fx-background-radius: 20;"));

        footer.getChildren().add(btnLogout);

        // --- ASSEMBLE ---
        mainLayout.setTop(header);
        mainLayout.setCenter(dashboardGrid);
        mainLayout.setBottom(footer);

        stage.setTitle("EMS Admin Dashboard - " + adminName);
        stage.setScene(new Scene(mainLayout, 1300, 850)); // Increased width slightly for logos
        stage.centerOnScreen();
        stage.show();
    }

    private VBox createFunctionalCard(String title, String description, String colorHex) {
        VBox card = new VBox(15);
        card.setPrefSize(280, 220);
        card.setAlignment(Pos.CENTER);
        card.setPadding(new Insets(20));
        
        card.setStyle("-fx-background-color: #FFFFFF; " +
                      "-fx-border-color: " + colorHex + "; " + 
                      "-fx-border-width: 3px; " +
                      "-fx-border-radius: 12px; " +
                      "-fx-background-radius: 12px; " +
                      "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0, 0, 5);");
        
        Label lblTitle = new Label(title);
        lblTitle.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        lblTitle.setTextFill(Color.web(colorHex));

        Label lblDesc = new Label(description);
        lblDesc.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 13px;");
        
        Button btnOpen = new Button("Open Module");
        String normalStyle = "-fx-background-color: " + colorHex + "; -fx-text-fill: white; -fx-font-weight: bold; -fx-cursor: hand; -fx-background-radius: 5;";
        btnOpen.setStyle(normalStyle);
        
        card.getChildren().addAll(lblTitle, lblDesc, btnOpen);
        
        card.setOnMouseEntered(e -> card.setStyle(card.getStyle() + "-fx-background-color: #F9F9F9; -fx-translate-y: -5;"));
        card.setOnMouseExited(e -> card.setStyle(card.getStyle().replace("-fx-background-color: #F9F9F9; -fx-translate-y: -5;", "")));

        return card;
    }
}