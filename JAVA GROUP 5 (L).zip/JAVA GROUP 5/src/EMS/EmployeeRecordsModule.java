package EMS;

import java.sql.*;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class EmployeeRecordsModule {

    private Stage stage;
    private static ObservableList<Employee> employeeData = FXCollections.observableArrayList();
    private TableView<Employee> table = new TableView<>();
    private ToggleGroup sexGroup = new ToggleGroup();

    public EmployeeRecordsModule(Stage stage) {
        this.stage = stage;
        loadFromDatabase(); 
    }

    public static ObservableList<Employee> getEmployeeData() {
        return employeeData; 
    }

    public static Employee getEmployeeById(String id) {
        if (id == null) return null;
        for (Employee e : employeeData) {
            if (e.getId().equalsIgnoreCase(id.trim())) {
                return e;
            }
        }
        return null;
    }

    public void show() {
        VBox mainLayout = new VBox(15);
        mainLayout.setPadding(new Insets(20));
        mainLayout.setStyle("-fx-background-color: #f4f7f6;");

        Label header = new Label("EMPLOYEE DATABASE MANAGEMENT");
        header.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #2C3E50;");

        TextField searchField = new TextField();
        searchField.setPromptText("🔍 Search by Employee ID...");
        searchField.setMaxWidth(350);

        FilteredList<Employee> filteredData = new FilteredList<>(employeeData, p -> true);
        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            filteredData.setPredicate(emp -> {
                if (newVal == null || newVal.isEmpty()) return true;
                return emp.getId().toLowerCase().contains(newVal.toLowerCase());
            });
        });
        table.setItems(filteredData);

        // --- INPUT FORM ---
        GridPane grid = new GridPane();
        grid.setHgap(15); grid.setVgap(12);
        grid.setPadding(new Insets(10));

        TextField idField = new TextField(); 
        idField.setPromptText("Ex: WDU001");
        TextField firstNameField = new TextField(); 
        TextField lastNameField = new TextField(); 
        TextField ageField = new TextField(); 
        TextField salaryField = new TextField(); 
        
        RadioButton rbMale = new RadioButton("Male");
        rbMale.setToggleGroup(sexGroup);
        rbMale.setUserData("Male");
        
        RadioButton rbFemale = new RadioButton("Female");
        rbFemale.setToggleGroup(sexGroup);
        rbFemale.setUserData("Female");
        
        HBox sexContainer = new HBox(10, rbMale, rbFemale);

        // --- UPDATED: 7 DEPARTMENTS ---
        ComboBox<String> deptBox = new ComboBox<>(FXCollections.observableArrayList(
            "Administration", "IT Support", "Human Resources", 
            "Finance", "Academic Affairs", "Student Services", "Maintenance"
        ));
        deptBox.setPromptText("Select Dept");
        deptBox.setMaxWidth(Double.MAX_VALUE);

        ComboBox<String> roleBox = new ComboBox<>(FXCollections.observableArrayList("Admin", "Employee"));
        roleBox.setPromptText("Select Role");
        roleBox.setMaxWidth(Double.MAX_VALUE);

        grid.addRow(0, new Label("ID:"), idField, new Label("First Name:"), firstNameField);
        grid.addRow(1, new Label("Last Name:"), lastNameField, new Label("Age:"), ageField);
        grid.addRow(2, new Label("Dept:"), deptBox, new Label("Role:"), roleBox);
        grid.addRow(3, new Label("Salary ($):"), salaryField, new Label("Sex:"), sexContainer);

        Button btnAdd = new Button("Add Record");
        btnAdd.setStyle("-fx-background-color: #27AE60; -fx-text-fill: white; -fx-font-weight: bold;");
        
        Button btnUpdate = new Button("Update");
        btnUpdate.setStyle("-fx-background-color: #2980B9; -fx-text-fill: white; -fx-font-weight: bold;");
        
        Button btnDelete = new Button("Delete");
        btnDelete.setStyle("-fx-background-color: #E74C3C; -fx-text-fill: white; -fx-font-weight: bold;");
        
        Button btnBack = new Button("Back");

        btnAdd.setOnAction(e -> handleAdd(idField, firstNameField, lastNameField, ageField, salaryField, deptBox, roleBox));
        btnUpdate.setOnAction(e -> handleUpdate(idField, firstNameField, lastNameField, ageField, salaryField, deptBox, roleBox));
        btnDelete.setOnAction(e -> handleDelete(idField, firstNameField, lastNameField, ageField, salaryField, deptBox, roleBox));
        btnBack.setOnAction(e -> new AdminDashboard(stage, "Admin").show());

        setupTable();
        
        table.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                idField.setText(newVal.getId());
                firstNameField.setText(newVal.getFirstName());
                lastNameField.setText(newVal.getLastName());
                ageField.setText(String.valueOf(newVal.getAge()));
                
                if ("Male".equals(newVal.getSex())) rbMale.setSelected(true);
                else if ("Female".equals(newVal.getSex())) rbFemale.setSelected(true);
                
                deptBox.setValue(newVal.getDepartment());
                salaryField.setText(newVal.getSalary());
                roleBox.setValue(newVal.getRole());
            }
        });

        HBox btnBar = new HBox(10, btnAdd, btnUpdate, btnDelete, btnBack);
        mainLayout.getChildren().addAll(header, searchField, grid, btnBar, table);
        
        stage.setScene(new Scene(mainLayout, 950, 800));
        stage.setTitle("Employee Management Module");
        stage.show();
    }

    private void loadFromDatabase() {
        employeeData.clear();
        String sql = "SELECT * FROM employees";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                employeeData.add(new Employee(
                    rs.getString("id"), rs.getString("firstName"), rs.getString("lastName"),
                    rs.getInt("age"), rs.getString("sex"), rs.getString("department"), 
                    rs.getString("salary"), rs.getString("role")
                ));
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }

    private boolean isAdminExists() {
        for (Employee e : employeeData) {
            if ("Admin".equalsIgnoreCase(e.getRole())) return true;
        }
        return false;
    }

    private void handleAdd(TextField i, TextField fn, TextField ln, TextField a, TextField s, ComboBox<String> d, ComboBox<String> r) {
        if (validate(i, fn, ln, a, d, r, s)) {
            if ("Admin".equalsIgnoreCase(r.getValue()) && isAdminExists()) {
                showAlert("Restriction", "An Admin record already exists.");
                return;
            }

            String sql = "INSERT INTO employees (id, firstName, lastName, age, sex, department, salary, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, i.getText());
                pstmt.setString(2, fn.getText());
                pstmt.setString(3, ln.getText());
                pstmt.setInt(4, Integer.parseInt(a.getText()));
                pstmt.setString(5, sexGroup.getSelectedToggle().getUserData().toString());
                pstmt.setString(6, d.getValue());
                pstmt.setString(7, s.getText());
                pstmt.setString(8, r.getValue());
                
                pstmt.executeUpdate();
                loadFromDatabase();
                clearFields(i, fn, ln, a, s, d, r);
            } catch (SQLException ex) { 
                showAlert("Warning", "ID already exists or Database error."); 
            }
        }
    }

    private void handleUpdate(TextField i, TextField fn, TextField ln, TextField a, TextField s, ComboBox<String> d, ComboBox<String> r) {
        Employee selected = table.getSelectionModel().getSelectedItem();
        if (selected != null && validate(i, fn, ln, a, d, r, s)) {
            String sql = "UPDATE employees SET id=?, firstName=?, lastName=?, age=?, sex=?, department=?, salary=?, role=? WHERE id=?";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, i.getText());
                pstmt.setString(2, fn.getText());
                pstmt.setString(3, ln.getText());
                pstmt.setInt(4, Integer.parseInt(a.getText()));
                pstmt.setString(5, sexGroup.getSelectedToggle().getUserData().toString());
                pstmt.setString(6, d.getValue());
                pstmt.setString(7, s.getText());
                pstmt.setString(8, r.getValue());
                pstmt.setString(9, selected.getId());
                
                pstmt.executeUpdate();
                loadFromDatabase(); 
                clearFields(i, fn, ln, a, s, d, r);
            } catch (SQLException ex) { showAlert("Update Error", ex.getMessage()); }
        }
    }

    private void handleDelete(TextField i, TextField fn, TextField ln, TextField a, TextField s, ComboBox<String> d, ComboBox<String> r) {
        Employee selected = table.getSelectionModel().getSelectedItem();
        if (selected != null) {
            String sql = "DELETE FROM employees WHERE id=?";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, selected.getId());
                pstmt.executeUpdate();
                employeeData.remove(selected);
                clearFields(i, fn, ln, a, s, d, r);
            } catch (SQLException ex) { showAlert("Delete Error", ex.getMessage()); }
        }
    }

    private void setupTable() {
        TableColumn<Employee, String> colId = new TableColumn<>("ID");
        colId.setCellValueFactory(c -> c.getValue().idProperty());
        
        TableColumn<Employee, String> colFName = new TableColumn<>("First Name");
        colFName.setCellValueFactory(c -> c.getValue().firstNameProperty());
        
        TableColumn<Employee, String> colLName = new TableColumn<>("Last Name");
        colLName.setCellValueFactory(c -> c.getValue().lastNameProperty());
        
        TableColumn<Employee, String> colRole = new TableColumn<>("Role");
        colRole.setCellValueFactory(c -> c.getValue().roleProperty());
        
        TableColumn<Employee, String> colSal = new TableColumn<>("Base Salary");
        colSal.setCellValueFactory(c -> c.getValue().salaryProperty());
        
        TableColumn<Employee, Number> colage = new TableColumn<>("Age");
        colage.setCellValueFactory(c -> c.getValue().ageProperty());

        TableColumn<Employee, String> colsex = new TableColumn<>("Sex");
        colsex.setCellValueFactory(c -> c.getValue().sexProperty());

        TableColumn<Employee, String> coldepartment = new TableColumn<>("Department");
        coldepartment.setCellValueFactory(c -> c.getValue().departmentProperty());

        table.getColumns().setAll(colId, colFName, colLName, colRole, colSal, colage, colsex, coldepartment);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    private boolean validate(TextField i, TextField fn, TextField ln, TextField a, ComboBox<String> d, ComboBox<String> r, TextField s) {
        try {
            if (i.getText().isEmpty() || fn.getText().isEmpty() || ln.getText().isEmpty() || 
                sexGroup.getSelectedToggle() == null || d.getValue() == null || r.getValue() == null || s.getText().isEmpty()) {
                showAlert("Validation Error", "All fields must be filled.");
                return false;
            }

            // --- ID VALIDATION: Character + Number ---
            String idVal = i.getText().trim();
            boolean hasLetter = idVal.matches(".*[a-zA-Z].*");
            boolean hasDigit = idVal.matches(".*[0-9].*");
            
            if (!hasLetter || !hasDigit) {
                showAlert("ID Format Error", "ID must contain both letters and numbers (e.g., WDU123).");
                return false;
            }
            
            int ageValue = Integer.parseInt(a.getText());
            if (ageValue < 18) {
                showAlert("Age Restriction", "Employee must be 18 years or older.");
                return false;
            }
            
            return true;
        } catch (NumberFormatException e) { 
            showAlert("Input Error", "Age must be a valid number.");
            return false; 
        }
    }

    private void clearFields(TextField i, TextField fn, TextField ln, TextField a, TextField s, ComboBox<String> d, ComboBox<String> r) {
        i.clear(); fn.clear(); ln.clear(); a.clear(); s.clear(); 
        if(sexGroup.getSelectedToggle() != null) sexGroup.getSelectedToggle().setSelected(false);
        d.setValue(null); r.setValue(null);
    }

    private void showAlert(String t, String m) {
        new Alert(Alert.AlertType.WARNING, m).show();
    }
}

class Employee {
    private final StringProperty id, firstName, lastName, sex, department, salary, role;
    private final IntegerProperty age;

    public Employee(String id, String firstName, String lastName, int age, String sex, String department, String salary, String role) {
        this.id = new SimpleStringProperty(id);
        this.firstName = new SimpleStringProperty(firstName);
        this.lastName = new SimpleStringProperty(lastName);
        this.age = new SimpleIntegerProperty(age);
        this.sex = new SimpleStringProperty(sex);
        this.department = new SimpleStringProperty(department);
        this.salary = new SimpleStringProperty(salary);
        this.role = new SimpleStringProperty(role);
    }

    public StringProperty idProperty() { return id; }
    public StringProperty firstNameProperty() { return firstName; }
    public StringProperty lastNameProperty() { return lastName; }
    public StringProperty roleProperty() { return role; }
    public StringProperty salaryProperty() { return salary; }
    public StringProperty sexProperty() { return sex; }
    public IntegerProperty ageProperty() { return age; }
    public StringProperty departmentProperty() { return department; }

    public String getId() { return id.get(); }
    public String getFirstName() { return firstName.get(); }
    public String getLastName() { return lastName.get(); }
    public int getAge() { return age.get(); }
    public String getSex() { return sex.get(); }
    public String getDepartment() { return department.get(); }
    public String getSalary() { return salary.get(); }
    public String getRole() { return role.get(); }

    public String getName() { 
        return firstName.get() + " " + lastName.get(); 
    }

    public void setId(String v) { 
        this.id.set(v); 
    }
    
    public double getBaseSalary() {
        try {
            return Double.parseDouble(salary.get().replaceAll("[^\\d.]", ""));
        } catch (Exception e) {
            return 0.0;
        }
    }
}