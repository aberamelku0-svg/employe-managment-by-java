package EMS;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * SHARED DATA BRIDGE: This class holds the list of leave requests 
 * submitted from LeaveRequest and processed by LeaveManagement.
 */
public class LeaveData {

    // Global list accessible across the system
    public static ObservableList<LeaveRecord> allRequests = FXCollections.observableArrayList();

    public static class LeaveRecord {
        private String id;
        private String fullName; // Added to store employee name
        private int days;
        private String reason;
        private String status;

        // Constructor 1: Used by the Employee (Step 1 - Requesting Leave)
        public LeaveRecord(String id, int days, String reason) {
            this.id = id;
            this.days = days;
            this.reason = reason;
            this.status = "Pending"; 
            this.fullName = ""; // Will be synced later by LeaveManagement
        }

        // Constructor 2: Used by Database Logic (Loading from MySQL)
        // This fixes the error: "new LeaveData.LeaveRecord(id, name, days, status)"
        public LeaveRecord(String id, String fullName, int days, String status) {
            this.id = id;
            this.fullName = fullName;
            this.days = days;
            this.status = status;
            this.reason = "General Leave"; // Default if reason isn't in DB
        }

        // --- Getters and Setters ---

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id; // Required for ID synchronization
        }

        public int getDays() {
            return days;
        }

        public void setDays(int days) {
            this.days = days;
        }

        public String getReason() {
            return reason;
        }

        public String getLeaveType() {
            return reason;
        }

        public void setReason(String reason) {
            this.reason = reason;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        // Fixed: Real implementation for Full Name
        public String getFullName() {
            return fullName;
        }

        public void setFullName(String name) {
            this.fullName = name;
        }
    }
}