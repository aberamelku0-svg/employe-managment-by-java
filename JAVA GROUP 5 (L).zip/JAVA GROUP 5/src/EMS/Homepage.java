package EMS;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class Homepage extends Application {

    private Stage stage;

    @Override
    public void start(Stage primaryStage) {
        this.stage = primaryStage;
        show();
    }

    public void show() {
        VBox mainLayout = new VBox(25);
        mainLayout.setPadding(new Insets(40));
        mainLayout.setAlignment(Pos.CENTER);
        mainLayout.setStyle("-fx-background-color: green;");

        // --- University Logo ---
        try {
            Image logo = new Image(getClass().getResourceAsStream("wdu.jpg"));
            ImageView logoView = new ImageView(logo);
            logoView.setFitWidth(160);
            logoView.setPreserveRatio(true);
            mainLayout.getChildren().add(logoView);
        } catch (Exception e) {
            System.out.println("Logo 'wdu.jpg' not found in logincontroller folder.");
        }

        // --- University Header ---
        Label welcomeLabel = new Label("WOLDIYA UNIVERSITY");
        welcomeLabel.setStyle("-fx-font-size: 30px; -fx-font-weight: bold; -fx-text-fill: #27AE60;");

        Label subHeader = new Label("Building the Future through Knowledge");
        subHeader.setStyle("-fx-font-size: 16px; -fx-italic: true; -fx-text-fill: #7F8C8D;");

        // --- Woldiya University Description ---
        Text description = new Text(
            "Woldiya University (WDU) is a public higher education institution in Ethiopia, " +
            "located in Weldiya, Amhara Region. It is dedicated to providing quality education, " +
            "problem-solving research, and community service, with a focus on Technology, " +
            "Engineering, and the Humanities."
        );
        description.setWrappingWidth(600);
        description.setTextAlignment(TextAlignment.CENTER);
        description.setStyle("-fx-font-size: 15px; -fx-fill: #2C3E50; -fx-line-spacing: 6;");

        // --- Navigation Button ---
        Button btnNext = new Button("Proceed to Login →");
        btnNext.setPrefWidth(250);
        btnNext.setStyle("-fx-background-color: #27AE60; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 12;");

        // FIX: Ensure this calls the correct class name (LoginController)
        btnNext.setOnAction(e -> {
            try {
                LoginController login = new LoginController(stage);
                login.show();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        mainLayout.getChildren().addAll(welcomeLabel, subHeader, description, btnNext);

        Scene scene = new Scene(mainLayout, 900, 700);
        stage.setScene(scene);
        stage.setTitle("Woldiya University - Welcome");
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}