package EMS;

import java.sql.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

/**
 * Reporting Module for system audits.
 * Features: Direct Database Querying and Automatic Report Archiving (Audit Log).
 */
public class ReportingModule {
    private Stage stage;
    private String currentAdminId = "Admin"; // Default ID for the log

    public ReportingModule(Stage stage) {
        this.stage = stage;
    }

    // Overloaded constructor to accept the real logged-in Admin ID
    public ReportingModule(Stage stage, String adminId) {
        this.stage = stage;
        this.currentAdminId = adminId;
    }

    public void show() {
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.TOP_CENTER);
        layout.setStyle("-fx-background-color: #fdfdfd;");

        Label header = new Label("SYSTEM AUDIT & REPORTING");
        header.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: #E74C3C;");

        TextArea reportArea = new TextArea();
        reportArea.setEditable(false);
        reportArea.setPromptText("Select a report type above to query the database...");
        reportArea.setPrefHeight(450);
        reportArea.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 13px;");

        HBox btnBox = new HBox(10);
        btnBox.setAlignment(Pos.CENTER);
        
        Button empBtn = new Button("Employee Report");
        Button leaveBtn = new Button("Leave Report");
        Button attendBtn = new Button("Attendance Report");
        Button salaryBtn = new Button("Salary Report");
        Button backBtn = new Button("Back to Dashboard");

        // --- 1. EMPLOYEE REPORT LOGIC ---
        empBtn.setOnAction(e -> {
            StringBuilder sb = new StringBuilder();
            sb.append("--- EMPLOYEE MASTER DATABASE LIST ---\n");
            sb.append(String.format("%-10s | %-20s | %-15s | %-10s\n", "ID", "FULL NAME", "DEPT", "ROLE"));
            sb.append("------------------------------------------------------------\n");
            
            try (Connection conn = DatabaseConnection.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM employees")) {
                while (rs.next()) {
                    String name = rs.getString("firstName") + " " + rs.getString("lastName");
                    sb.append(String.format("%-10s | %-20s | %-15s | %-10s\n", 
                        rs.getString("id"), name, rs.getString("department"), rs.getString("role")));
                }
                reportArea.setText(sb.toString());
                saveReportToDatabase("Employee Master List", sb.toString());
            } catch (SQLException ex) { reportArea.setText("Error: " + ex.getMessage()); }
        });

        // --- 2. LEAVE REPORT LOGIC ---
        leaveBtn.setOnAction(e -> {
            StringBuilder sb = new StringBuilder();
            sb.append("--- LEAVE SUMMARY AUDIT ---\n");
            sb.append(String.format("%-10s | %-20s | %-8s | %-10s\n", "ID", "FULL NAME", "DAYS", "STATUS"));
            sb.append("------------------------------------------------------------\n");

            try (Connection conn = DatabaseConnection.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM leavemanag")) {
                while (rs.next()) {
                    sb.append(String.format("%-10s | %-20s | %-8d | %-10s\n", 
                        rs.getString("employee_id"), rs.getString("fullName"), rs.getInt("requested_days"), rs.getString("status")));
                }
                reportArea.setText(sb.toString());
                saveReportToDatabase("Leave Audit Report", sb.toString());
            } catch (SQLException ex) { reportArea.setText("Error: " + ex.getMessage()); }
        });

        // --- 3. ATTENDANCE REPORT LOGIC ---
        attendBtn.setOnAction(e -> {
            StringBuilder sb = new StringBuilder();
            sb.append("--- ATTENDANCE & WORK-DAY AUDIT ---\n");
            sb.append(String.format("%-10s | %-10s | %-10s | %-10s\n", "ID", "PRESENT", "LEAVE", "TOTAL"));
            sb.append("------------------------------------------------------------\n");

            try (Connection conn = DatabaseConnection.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM attendance")) {
                while (rs.next()) {
                    int p = rs.getInt("present_days");
                    int l = rs.getInt("leave_days");
                    sb.append(String.format("%-10s | %-10d | %-10d | %-10d\n", 
                        rs.getString("employee_id"), p, l, (p + l)));
                }
                reportArea.setText(sb.toString());
                saveReportToDatabase("Attendance Audit", sb.toString());
            } catch (SQLException ex) { reportArea.setText("Error: " + ex.getMessage()); }
        });

        // --- 4. SALARY REPORT LOGIC ---
        salaryBtn.setOnAction(e -> {
            StringBuilder sb = new StringBuilder();
            sb.append("--- MONTHLY PAYROLL AUDIT (ETB) ---\n");
            sb.append(String.format("%-8s | %-18s | %-10s | %-10s | %-10s\n", "ID", "NAME", "GROSS", "TAX", "NET PAY"));
            sb.append("--------------------------------------------------------------------------------\n");

            try (Connection conn = DatabaseConnection.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM payroll")) {
                while (rs.next()) {
                    sb.append(String.format("%-8s | %-18s | %-10.2f | %-10.2f | %-10.2f\n", 
                        rs.getString("employee_id"), rs.getString("fullName"), 
                        rs.getDouble("gross_salary"), rs.getDouble("tax"), rs.getDouble("net_salary")));
                }
                reportArea.setText(sb.toString());
                saveReportToDatabase("Payroll Salary Report", sb.toString());
            } catch (SQLException ex) { reportArea.setText("Error: " + ex.getMessage()); }
        });

        backBtn.setOnAction(e -> new AdminDashboard(stage, "Admin").show());

        btnBox.getChildren().addAll(empBtn, leaveBtn, attendBtn, salaryBtn, backBtn);
        layout.getChildren().addAll(header, btnBox, reportArea);

        stage.setScene(new Scene(layout, 1000, 650));
        stage.setTitle("EMS - System Database Reporting");
        stage.show();
    }

    /**
     * ARCHIVE LOGIC:
     * Takes the whole 'content' (the report text) and stores it in the database.
     */
    private void saveReportToDatabase(String type, String content) {
        String sql = "INSERT INTO system_reports (admin_id, report_type, summary_text) VALUES (?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            // Check if Admin ID exists to avoid Foreign Key errors
            boolean exists = false;
            try (PreparedStatement check = conn.prepareStatement("SELECT id FROM employees WHERE id = ?")) {
                check.setString(1, currentAdminId);
                if (check.executeQuery().next()) exists = true;
            }

            if (exists) {
                pstmt.setString(1, currentAdminId);
            } else {
                pstmt.setNull(1, java.sql.Types.VARCHAR);
            }

            pstmt.setString(2, type);
            pstmt.setString(3, content); // Saves the entire TextArea block
            
            pstmt.executeUpdate();
            System.out.println("[Audit] Report archived successfully.");
            
        } catch (SQLException ex) {
            System.err.println("Audit storage failed: " + ex.getMessage());
        }
    }
}