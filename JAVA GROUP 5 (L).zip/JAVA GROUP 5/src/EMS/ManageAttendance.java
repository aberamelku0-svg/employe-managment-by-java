package EMS;

import java.sql.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

/**
 * STEP 2: ATTENDANCE VERIFICATION HUB
 * Updated: Sums multiple records for the same ID and displays Full Names.
 */
public class ManageAttendance {
    private Stage stage;

    // Public list for access by other modules
    public static ObservableList<AttendanceRecord> attendanceList = FXCollections.observableArrayList();

    public ManageAttendance(Stage stage) {
        this.stage = stage;
        loadFromDatabase(); 
    }

    public static AttendanceRecord getAttendanceById(String id) {
        if (id == null) return null;
        for (AttendanceRecord record : attendanceList) {
            if (record.getEmployeeId().trim().equalsIgnoreCase(id.trim())) {
                return record;
            }
        }
        return null;
    }

    /**
     * DATABASE LOGIC: Groups duplicate IDs and SUMS their present days.
     * Also fetches Full Names from the EmployeeRecordsModule.
     */
    private void loadFromDatabase() {
        attendanceList.clear();
        
        // SQL query that groups by ID and adds up the present days automatically
        String sql = "SELECT employee_id, SUM(present_days) as total_present, SUM(leave_days) as total_leave " +
                     "FROM attendance GROUP BY employee_id";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                String empId = rs.getString("employee_id");
                
                // Fetch Name from Employee Records
                Employee emp = EmployeeRecordsModule.getEmployeeById(empId);
                String fullName = (emp != null) ? emp.getName() : "Unknown Employee";

                AttendanceRecord record = new AttendanceRecord(
                    empId, 
                    fullName, 
                    rs.getInt("total_present")
                );
                
                // We keep leaveDays in the background logic for Salary calculations
                record.setLeaveDays(rs.getInt("total_leave")); 
                attendanceList.add(record);
            }
            System.out.println("Attendance data summed and loaded.");
            
        } catch (SQLException e) {
            System.err.println("Error loading attendance: " + e.getMessage());
        }
    }

    public static void recordAttendanceToDatabase(String empId, int present, int leave) {
        String sql = "INSERT INTO attendance (employee_id, present_days, leave_days) VALUES (?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE present_days = VALUES(present_days), leave_days = VALUES(leave_days)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, empId);
            pstmt.setInt(2, present);
            pstmt.setInt(3, leave);

            pstmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Database sync error: " + ex.getMessage());
        }
    }

    public void show() {
        BorderPane layout = new BorderPane();
        layout.setPadding(new Insets(20));
        layout.setStyle("-fx-background-color: #FDFEFE;");

        VBox topBox = new VBox(10);
        Label title = new Label("STEP 2: ATTENDANCE VERIFICATION HUB");
        title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: #2980B9;");
        
        Label hint = new Label("Consolidated working days for registered employees.");
        hint.setStyle("-fx-text-fill: #7F8C8D; -fx-font-style: italic;");
        
        topBox.getChildren().addAll(title, hint, new Separator());

        TableView<AttendanceRecord> table = new TableView<>(attendanceList);
        
        // ID Column
        TableColumn<AttendanceRecord, String> colId = new TableColumn<>("Employee ID");
        colId.setCellValueFactory(new PropertyValueFactory<>("employeeId"));

        // Full Name Column (Replaced Leave Days)
        TableColumn<AttendanceRecord, String> colName = new TableColumn<>("Full Name");
        colName.setCellValueFactory(new PropertyValueFactory<>("fullName"));

        // Present Days Column
        TableColumn<AttendanceRecord, Integer> colPresent = new TableColumn<>("Total Present Days");
        colPresent.setCellValueFactory(new PropertyValueFactory<>("daysPresent"));

        table.getColumns().addAll(colId, colName, colPresent);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        HBox navBar = new HBox(20);
        navBar.setPadding(new Insets(20, 0, 0, 0));
        navBar.setAlignment(Pos.CENTER);

        Button btnBack = new Button("« Back");
        btnBack.setOnAction(e -> new AdminDashboard(stage, "Admin").show());

        Button btnProceed = new Button("Proceed to Salary Management »");
        btnProceed.setStyle("-fx-background-color: #E67E22; -fx-text-fill: white; -fx-font-weight: bold;");
        btnProceed.setOnAction(e -> {
            new SalaryManagement(stage).show();
        });

        navBar.getChildren().addAll(btnBack, btnProceed);
        
        layout.setTop(topBox);
        layout.setCenter(table);
        layout.setBottom(navBar);

        stage.setScene(new Scene(layout, 900, 600));
        stage.setTitle("EMS - Manage Attendance");
        stage.show();
    }

    /**
     * DATA MODEL
     */
    public static class AttendanceRecord {
        private String employeeId;
        private String fullName;
        private int daysPresent;
        private int leaveDays;

        public AttendanceRecord(String id, String fullName, int presentDays) {
            this.employeeId = id;
            this.fullName = fullName;
            this.daysPresent = presentDays;
            this.leaveDays = 0; 
        }

        public String getEmployeeId() { return employeeId; }
        public String getFullName() { return fullName; }
        public int getDaysPresent() { return daysPresent; }
        public int getLeaveDays() { return leaveDays; }
        public void setLeaveDays(int days) { this.leaveDays = days; }

        void setEmployeeId(String newId) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        void setDaysPresent(int presentCount) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }
}