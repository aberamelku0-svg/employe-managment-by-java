package EMS;

import java.sql.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

/**
 * STEP 4: LEAVE APPLICATION
 * Fixed: Now directly inserts the request into the 'leavemanag' MySQL table 
 * so it appears on the Admin Leave Approval Board.
 */
public class LeaveRequest {
    private Stage stage;
    private String employeeName; 
    private String loggedInId;
    public LeaveRequest(Stage stage, String employeeName , String loggedInId) {
        this.stage = stage;
        this.employeeName = employeeName;
           this.loggedInId = loggedInId;
    }

    public void show() {
        VBox layout = new VBox(15);
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-background-color: #ffffff;");

        Label title = new Label("STEP 4: LEAVE APPLICATION");
        title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: #8E44AD;");

        TextField fullNameField = new TextField();
        fullNameField.setPromptText("Enter Full Name (First + Last)");
        fullNameField.setMaxWidth(250);

        TextField idConfirmField = new TextField();
        idConfirmField.setPromptText("Confirm Employee ID");
        idConfirmField.setMaxWidth(250);
        
        TextField daysField = new TextField();
        daysField.setPromptText("Number of Days");
        daysField.setMaxWidth(250);

        ComboBox<String> reasonBox = new ComboBox<>();
        reasonBox.getItems().addAll("Sick", "Vacation", "Personal", "Emergency");
        reasonBox.setPromptText("Select Reason for Leave");
        reasonBox.setPrefWidth(250);

        Button btnSubmit = new Button("SUBMIT LEAVE REQUEST");
        btnSubmit.setStyle("-fx-background-color: #8E44AD; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10 20; -fx-cursor: hand;");

        // --- BUTTON LOGIC ---
        btnSubmit.setOnAction(e -> {
            String inputName = fullNameField.getText().trim();
            String inputId = idConfirmField.getText().trim();
            
            Employee emp = EmployeeRecordsModule.getEmployeeById(inputId);
            
            if (emp == null) {
                showAlert(Alert.AlertType.ERROR, "ID Not Found", "The ID '" + inputId + "' does not exist.");
                return; 
            }

            if (!emp.getName().equalsIgnoreCase(inputName)) {
                showAlert(Alert.AlertType.ERROR, "Validation Error", "Name does not match the ID in our database.");
                return;
            }

            if ("Admin".equalsIgnoreCase(emp.getRole())) {
                showAlert(Alert.AlertType.ERROR, "Access Denied", "Admins cannot submit leave requests here.");
                return;
            }

            try {
                if (daysField.getText().isEmpty()) throw new NumberFormatException();
                int days = Integer.parseInt(daysField.getText());
                String reason = reasonBox.getValue() != null ? reasonBox.getValue() : "Not Specified";

                // --- CRITICAL FIX: INSERT INTO DATABASE ---
                if (saveRequestToDatabase(inputId, inputName, days)) {
                    // Update the local list for immediate viewing if dashboard is open
                    LeaveData.allRequests.add(new LeaveData.LeaveRecord(inputId, inputName, days, "Pending"));

                    showAlert(Alert.AlertType.INFORMATION, "Success", "Leave Request Submitted and Saved to Database.");
                    
                    // Security Logout/Redirect
                    new LoginController().showLogin(stage); 
                }

            } catch (NumberFormatException ex) {
                showAlert(Alert.AlertType.WARNING, "Numeric Error", "Please enter a valid number for 'Days'.");
            }
        });

        Button btnBack = new Button("Back to Dashboard");
        btnBack.setPrefWidth(250);
        btnBack.setOnAction(e -> new EmployeeDashboard(stage, employeeName, loggedInId).show());

        layout.getChildren().addAll(
            title, new Label("Full Name:"), fullNameField,
            new Label("Employee ID:"), idConfirmField, 
            new Label("Number of Days:"), daysField, 
            new Label("Reason:"), reasonBox, 
            btnSubmit, btnBack
        );

        stage.setScene(new Scene(layout, 500, 650));
        stage.show();
    }

    /**
     * Database persistence method to ensure the Leave Approval Board can see the data.
     */
    private boolean saveRequestToDatabase(String id, String name, int days) {
        String sql = "INSERT INTO leavemanag (employee_id, fullName, requested_days, status) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, id);
            pstmt.setString(2, name);
            pstmt.setInt(3, days);
            pstmt.setString(4, "Pending");
            
            pstmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Could not save request: " + ex.getMessage());
            return false;
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}