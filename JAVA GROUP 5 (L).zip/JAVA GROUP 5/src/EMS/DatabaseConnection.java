package EMS;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Handles centralized database connectivity for the Employee Management System.
 * Automatically creates 'employees', 'leavemanag', 'attendance', 'payroll', and 'system_reports' tables.
 */
public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/ems_db";
    private static final String USER = "root"; 
    private static final String PASSWORD = ""; 

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("JDBC Driver not found! Ensure the MySQL Connector JAR is added to your project.");
        }
    }

    /**
     * Automatically creates the necessary tables if they do not exist.
     */
    public static void initializeDatabase() {
        // 1. Employee Table SQL
        String createEmployeeTable = "CREATE TABLE IF NOT EXISTS employees ("
                + "id VARCHAR(20) PRIMARY KEY, "
                + "firstName VARCHAR(50) NOT NULL, "
                + "lastName VARCHAR(50) NOT NULL, "
                + "age INT NOT NULL, "
                + "sex VARCHAR(10), "
                + "department VARCHAR(50), "
                + "salary VARCHAR(20), "
                + "role VARCHAR(20)"
                + ");";

        // 2. Leave Management Table SQL
        String createLeaveManagTable = "CREATE TABLE IF NOT EXISTS leavemanag ("
                + "employee_id VARCHAR(20) PRIMARY KEY, "
                + "fullName VARCHAR(100) NOT NULL, "
                + "requested_days INT NOT NULL, "
                + "status VARCHAR(20) DEFAULT 'Pending', "
                + "FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE"
                + ");";

        // 3. Attendance Table SQL
        String createAttendanceTable = "CREATE TABLE IF NOT EXISTS attendance ("
                + "attendance_id INT AUTO_INCREMENT PRIMARY KEY, "
                + "employee_id VARCHAR(20), "
                + "present_days INT DEFAULT 0, "
                + "leave_days INT DEFAULT 0, "
                + "FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE"
                + ");";

        // 4. Payroll/Salary Table SQL
        String createPayrollTable = "CREATE TABLE IF NOT EXISTS payroll ("
                + "employee_id VARCHAR(20) PRIMARY KEY, "
                + "fullName VARCHAR(100) NOT NULL, "
                + "present_days INT, "
                + "leave_days INT, "
                + "gross_salary DOUBLE, "
                + "pension DOUBLE, "
                + "tax DOUBLE, "
                + "net_salary DOUBLE, "
                + "FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE"
                + ");";

        // 5. System Audit/Reporting Logs Table (NEW)
        String createReportLogsTable = "CREATE TABLE IF NOT EXISTS system_reports ("
                + "report_id INT AUTO_INCREMENT PRIMARY KEY, "
                + "admin_id VARCHAR(20), "
                + "report_type VARCHAR(50) NOT NULL, " // e.g., 'Salary Report', 'Attendance Audit'
                + "generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "
                + "summary_text TEXT, "
                + "FOREIGN KEY (admin_id) REFERENCES employees(id) ON DELETE SET NULL"
                + ");";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            
            // Create Employees
            stmt.execute(createEmployeeTable);
            System.out.println("Database initialization: Table 'employees' is ready.");

            // Create leavemanag
            stmt.execute(createLeaveManagTable);
            System.out.println("Database initialization: Table 'leavemanag' is ready.");
            
            // Create Attendance
            stmt.execute(createAttendanceTable);
            System.out.println("Database initialization: Table 'attendance' is ready.");

            // Create Payroll
            stmt.execute(createPayrollTable);
            System.out.println("Database initialization: Table 'payroll' is ready.");

            // Create System Reports Audit Log
            stmt.execute(createReportLogsTable);
            System.out.println("Database initialization: Table 'system_reports' is ready.");
            
        } catch (SQLException e) {
            System.err.println("Database initialization failed: " + e.getMessage());
        }
    }

    public static void testConnection() {
        try (Connection conn = getConnection()) {
            if (conn != null) {
                System.out.println("Successfully connected to the ems_db database!");
            }
        } catch (SQLException e) {
            System.err.println("Connection failed: " + e.getMessage());
        }
    }
}