package EMS;

import javafx.application.Application;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;
public class LoginController extends Application {
 private Stage stage;
 // Default constructor for JavaFX launc
    public LoginController() {

 }// Constructor used by Homepage to pass the existing Stage
    public LoginController(Stage stage) {
        this.stage = stage; }
    public void show() {
        showLogin(this.stage);}
    public void showLogin(Stage stage) {

        // Initialize the stage reference if it wasn't set via constructor

        this.stage = stage;
        new EmployeeRecordsModule(stage);
        VBox layout = new VBox(15); 
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20, 50, 40, 50));
        layout.setStyle("-fx-background-color: WHITE;");
        HBox logoHeader = new HBox();
        logoHeader.setAlignment(Pos.CENTER);
        logoHeader.setPrefWidth(400);
        ImageView leftLogo = new ImageView();

        try {
            leftLogo.setImage(new Image(getClass().getResourceAsStream("/logincontroller/Woldiya-University.png")));
            leftLogo.setFitHeight(80);
            leftLogo.setPreserveRatio(true);
        } catch (Exception e) { System.out.println("Left logo not found"); }

        // Right Logo: WDU
        ImageView rightLogo = new ImageView();
        try {
            rightLogo.setImage(new Image(getClass().getResourceAsStream("/logincontroller/WDU.jpg")));
            rightLogo.setFitHeight(80);
            rightLogo.setPreserveRatio(true);
        } catch (Exception e) { System.out.println("Right logo not found"); }

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        logoHeader.getChildren().addAll(leftLogo, spacer, rightLogo);

        // --- TITLE (University Colors: Deep Green) ---
        Label title = new Label("EMPLOYEE MANAGEMENT SYSTEM for\nWOLDIYA UNIVERSITY");
        title.setTextAlignment(TextAlignment.CENTER);
        title.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        title.setTextFill(Color.web("#27AE60")); // Woldiya University Green
        // --- INPUT FIELDS WITH LABELS ---
        // Username Section

        VBox userBox = new VBox(5);
        userBox.setAlignment(Pos.CENTER_LEFT);
        userBox.setMaxWidth(280);
        Label lblUser = new Label("Username (First Name):");
        lblUser.setFont(Font.font("Arial", FontWeight.BOLD, 13));
        lblUser.setTextFill(Color.web("#2C3E50"));
        TextField usernameField = new TextField();
        usernameField.setPromptText("Enter First Name");
        usernameField.setStyle("-fx-padding: 10; -fx-border-color: #27AE60; -fx-border-radius: 5; -fx-background-radius: 5;");
        userBox.getChildren().addAll(lblUser, usernameField);

        // Password Section
        VBox passBox = new VBox(5);
        passBox.setAlignment(Pos.CENTER_LEFT);
        passBox.setMaxWidth(280);
        Label lblPass = new Label("Password (Employee ID):");
        lblPass.setFont(Font.font("Arial", FontWeight.BOLD, 13));
        lblPass.setTextFill(Color.web("#2C3E50"));
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter ID Number");
        passwordField.setStyle("-fx-padding: 10; -fx-border-color: #27AE60; -fx-border-radius: 5; -fx-background-radius: 5;");
        passBox.getChildren().addAll(lblPass, passwordField);

        // Role Section
        VBox roleBox = new VBox(5);
        roleBox.setAlignment(Pos.CENTER_LEFT);
        roleBox.setMaxWidth(280);
        Label lblRole = new Label("System Role:");
        lblRole.setFont(Font.font("Arial", FontWeight.BOLD, 13));
        lblRole.setTextFill(Color.web("#2C3E50"));
        ComboBox<String> roleComboBox = new ComboBox<>();
        roleComboBox.getItems().addAll("Admin", "Employee");
        roleComboBox.setPromptText("Select Role");
        roleComboBox.setPrefWidth(280);
        roleComboBox.setStyle("-fx-border-color: #27AE60; -fx-border-radius: 5;");
        roleBox.getChildren().addAll(lblRole, roleComboBox);
        // --- LOGIN BUTTON (Deep Green) ---
        Button loginButton = new Button("SECURE LOGIN");
        loginButton.setStyle("-fx-background-color: #27AE60; -fx-text-fill: white; -fx-font-weight: bold; -fx-cursor: hand; -fx-background-radius: 5;");
        loginButton.setPrefWidth(280);
        loginButton.setPrefHeight(45);
        // Hover effect for button
        loginButton.setOnMouseEntered(e -> loginButton.setStyle("-fx-background-color: #219150; -fx-text-fill: white; -fx-font-weight: bold; -fx-cursor: hand; -fx-background-radius: 5;"));
        loginButton.setOnMouseExited(e -> loginButton.setStyle("-fx-background-color: #27AE60; -fx-text-fill: white; -fx-font-weight: bold; -fx-cursor: hand; -fx-background-radius: 5;"));

        Label statusLabel = new Label();
        statusLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        loginButton.setOnAction(e -> {
            String user = usernameField.getText().trim();
            String pass = passwordField.getText().trim();
            String selectedRole = roleComboBox.getValue();
            if (user.isEmpty() || pass.isEmpty() || selectedRole == null) {
                statusLabel.setTextFill(Color.web("#C0392B")); // Red for error
                statusLabel.setText("All fields are required!");
                return; }
            boolean anyAdminExists = false;
            for (Employee emp : EmployeeRecordsModule.getEmployeeData()) {
                if ("Admin".equalsIgnoreCase(emp.getRole())) {
                    anyAdminExists = true;
                    break;  }  }
            for (Employee emp : EmployeeRecordsModule.getEmployeeData()) {
                if (emp.getFirstName().equalsIgnoreCase(user) && emp.getId().equals(pass)) {

                    if ("Admin".equals(selectedRole) && "Admin".equalsIgnoreCase(emp.getRole())) {
                        new AdminDashboard(stage, user).show();
                        return;
                    } 
                    else if ("Employee".equals(selectedRole) && "Employee".equalsIgnoreCase(emp.getRole())) {
                        new EmployeeDashboard(stage, user,pass).show();
                        return;}} }
            if ("Admin".equals(selectedRole) && !anyAdminExists) {
                new AdminDashboard(stage, user).show();
            } else {
                statusLabel.setTextFill(Color.web("#C0392B"));
                statusLabel.setText("Invalid credentials or role.");  }
        });
        // Assemble layout
        layout.getChildren().addAll(
            logoHeader,  title,  new Separator(),   userBox,  passBox,roleBox,  loginButton, statusLabel  );
        Scene scene = new Scene(layout, 500, 680);
        stage.setTitle("Woldiya University - EMS Login");
        stage.setScene(scene);
        stage.setResizable(false); 
        stage.centerOnScreen();
        stage.show();
    }
    @Override
    public void start(Stage primaryStage) {
        DatabaseConnection.initializeDatabase(); 
        showLogin(primaryStage);  }
}