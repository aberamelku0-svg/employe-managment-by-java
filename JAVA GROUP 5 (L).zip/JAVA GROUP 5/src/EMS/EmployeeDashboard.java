package EMS;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class EmployeeDashboard {

    private Stage stage;
    private String employeeName;
    private String currentEmployeeId; 

    /**
     * PRIMARY CONSTRUCTOR
     * Use this one to properly receive data from LoginController.
     */
    public EmployeeDashboard(Stage stage, String employeeName, String currentEmployeeId) {
        this.stage = stage;
        this.employeeName = employeeName;
        this.currentEmployeeId = currentEmployeeId;
    }

    // --- REMOVED THE OLD CONSTRUCTOR THAT CAUSED THE "NOT SUPPORTED YET" ERROR ---

    public void show() {
        BorderPane mainLayout = new BorderPane();

        // --- TOP HEADER WITH LOGOS ---
        HBox header = new HBox(15);
        header.setPadding(new Insets(10, 25, 10, 25)); 
        header.setAlignment(Pos.CENTER);
        header.setStyle("-fx-background-color: #27AE60; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 10, 0, 0, 0);"); 

        // Left Logo
        ImageView leftLogo = new ImageView();
        try {
            leftLogo.setImage(new Image(getClass().getResourceAsStream("/logincontroller/Woldiya-University.png")));
            leftLogo.setFitHeight(60);
            leftLogo.setPreserveRatio(true);
        } catch (Exception e) { System.out.println("Left logo not found"); }

        Label title = new Label(" EMPLOYEE PORTAL");
        title.setTextFill(Color.WHITE);
        title.setFont(Font.font("Arial", FontWeight.BOLD, 26));
        
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        
        Label userLabel = new Label("Welcome, " + employeeName);
        userLabel.setTextFill(Color.WHITE);
        userLabel.setFont(Font.font("Arial", FontWeight.MEDIUM, 14));

        // Right Logo
        ImageView rightLogo = new ImageView();
        try {
            rightLogo.setImage(new Image(getClass().getResourceAsStream("/logincontroller/WDU.jpg")));
            rightLogo.setFitHeight(60);
            rightLogo.setPreserveRatio(true);
        } catch (Exception e) { System.out.println("Right logo not found"); }

        header.getChildren().addAll(leftLogo, title, spacer, userLabel, rightLogo);

        // --- CENTER AREA (Horizontal Structure) ---
        HBox dashboardHBox = new HBox(30); 
        dashboardHBox.setPadding(new Insets(40)); 
        dashboardHBox.setAlignment(Pos.CENTER);

        // Card 2: Attendance
        VBox card2 = createFunctionalCard("Attendance Form", "Punch-in/out and view work logs.", "#2980B9");
        ((Button) card2.getChildren().get(2)).setOnAction(e -> {
            new AttendanceForm(stage).show(); 
        });

        // Card 3: Leave
        VBox card3 = createFunctionalCard("Leave Request", "Apply for leave and check status.", "#8E44AD");
        ((Button) card3.getChildren().get(2)).setOnAction(e -> {
            new LeaveRequest(stage, employeeName,currentEmployeeId).show();
        });

        // Card 4: Salary View (FIXED: Now passes the ID correctly)
        VBox card4 = createFunctionalCard("Salary View", "View payslips and salary history.", "#16A085");
        ((Button) card4.getChildren().get(2)).setOnAction(e -> {
             // Calling the new SalaryView logic with the stored ID
             new SalaryView(stage, employeeName, currentEmployeeId).show(); 
        });

        dashboardHBox.getChildren().addAll(card2, card3, card4);

        ScrollPane scrollPane = new ScrollPane(dashboardHBox);
        scrollPane.setFitToHeight(true);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color:transparent; -fx-background: transparent;");

        // --- BOTTOM AREA (Logout) ---
        Button logoutBtn = new Button("Logout");
        logoutBtn.setStyle("-fx-background-color: #c0392b; -fx-text-fill: white; -fx-font-weight: bold; -fx-cursor: hand;");
        logoutBtn.setPrefSize(150, 35);
        logoutBtn.setOnAction(e -> new LoginController().showLogin(stage));
        
        VBox bottomArea = new VBox(logoutBtn);
        bottomArea.setAlignment(Pos.CENTER);
        bottomArea.setPadding(new Insets(20));

        mainLayout.setTop(header);
        mainLayout.setCenter(scrollPane);
        mainLayout.setBottom(bottomArea);

        Scene scene = new Scene(mainLayout, 1100, 650); 
        stage.setTitle("EMS - Employee Dashboard");
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.show();
    }

    private VBox createFunctionalCard(String title, String description, String colorHex) {
        VBox card = new VBox(12);
        card.setPrefSize(280, 220);
        card.setAlignment(Pos.CENTER);
        card.setPadding(new Insets(20));
        
        card.setStyle("-fx-background-color: #FFFFFF; " +
                      "-fx-border-color: " + colorHex + "; " +
                      "-fx-border-width: 2px; " +
                      "-fx-border-radius: 8px; " +
                      "-fx-background-radius: 8px; " +
                      "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 10, 0, 0, 5);");

        Label lblTitle = new Label(title);
        lblTitle.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        lblTitle.setTextFill(Color.web(colorHex));
        
        Label lblDesc = new Label(description);
        lblDesc.setWrapText(true);
        lblDesc.setAlignment(Pos.CENTER);
        lblDesc.setStyle("-fx-text-fill: #555555; -fx-text-alignment: center;");

        Button btnAction = new Button("Access Module");
        btnAction.setStyle("-fx-background-color: " + colorHex + "; -fx-text-fill: white; -fx-cursor: hand; -fx-font-weight: bold;");

        card.getChildren().addAll(lblTitle, lblDesc, btnAction);
        
        card.setOnMouseEntered(e -> card.setStyle(card.getStyle() + "-fx-background-color: #F9F9F9; -fx-translate-y: -5;"));
        card.setOnMouseExited(e -> card.setStyle(card.getStyle() + "-fx-background-color: #FFFFFF; -fx-translate-y: 0;"));

        return card;
    }
}