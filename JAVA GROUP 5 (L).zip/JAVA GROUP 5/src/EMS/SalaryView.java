package EMS;

import java.sql.*;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 * Role: Salary Enquiry Dashboard (View-Only)
 * Logic: Synchronized with the 'payroll' table managed by SalaryManagement.
 */
public class SalaryView {

    private Stage stage;
    private String employeeName;
    private String loggedInId; 

    public SalaryView(Stage stage, String employeeName, String loggedInId) {
        this.stage = stage;
        this.employeeName = employeeName;
        this.loggedInId = loggedInId;
    }

    public void show() {
        VBox mainLayout = new VBox(20);
        mainLayout.setPadding(new Insets(30));
        mainLayout.setAlignment(Pos.TOP_CENTER);
        mainLayout.setStyle("-fx-background-color: #FFFFFF; -fx-border-color: #27AE60; -fx-border-width: 5;");

        // --- 1. BRANDING HEADER ---
        HBox branding = new HBox(15);
        branding.setAlignment(Pos.CENTER);
        try {
            ImageView logo = new ImageView(new Image(getClass().getResourceAsStream("/logincontroller/Woldiya-University.png")));
            logo.setFitHeight(70);
            logo.setPreserveRatio(true);
            branding.getChildren().add(logo);
        } catch (Exception e) { System.out.println("Logo not found."); }

        Label title = new Label("OFFICIAL SALARY RECORD");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 22));
        title.setTextFill(Color.web("#27AE60"));

        // --- 2. ID ENTRY GATE ---
        VBox searchPanel = new VBox(15);
        searchPanel.setPadding(new Insets(20));
        searchPanel.setAlignment(Pos.CENTER);
        searchPanel.setStyle("-fx-background-color: #F4F6F7; -fx-background-radius: 15; -fx-border-color: #BDC3C7;");
        searchPanel.setMaxWidth(400);

        Label lblInstruction = new Label("Please enter your ID to fetch your salary record.");
        lblInstruction.setStyle("-fx-font-size: 13px; -fx-text-fill: #7F8C8D;");

        TextField idEntryField = new TextField();
        idEntryField.setPromptText("Enter Employee ID");
        idEntryField.setPrefHeight(40);

        Button btnView = new Button("FETCH SALARY RECORD");
        btnView.setPrefWidth(Double.MAX_VALUE);
        btnView.setPrefHeight(40);
        btnView.setStyle("-fx-background-color: #27AE60; -fx-text-fill: white; -fx-font-weight: bold; -fx-cursor: hand;");

        searchPanel.getChildren().addAll(lblInstruction, idEntryField, btnView);

        // --- 3. THE DISPLAY AREA ---
        GridPane slipGrid = new GridPane();
        slipGrid.setVgap(12);
        slipGrid.setHgap(25);
        slipGrid.setAlignment(Pos.CENTER);
        slipGrid.setPadding(new Insets(20));
        slipGrid.setStyle("-fx-background-color: #FFFFFF; -fx-border-color: #DCDCDC; -fx-border-radius: 10;");
        slipGrid.setVisible(false); 

        // --- 4. VIEW LOGIC ---
        btnView.setOnAction(e -> {
            String enteredId = idEntryField.getText().trim();

            if (!enteredId.equalsIgnoreCase(loggedInId)) {
                showAlert(Alert.AlertType.ERROR, "Security Error", "ID does not match logged-in session.");
                return;
            }

            fetchRecordFromDatabase(enteredId, slipGrid, searchPanel);
        });

        Button btnReturn = new Button("BACK TO DASHBOARD");
        btnReturn.setPrefWidth(200);
        btnReturn.setOnAction(e -> new EmployeeDashboard(stage, employeeName, loggedInId).show());

        mainLayout.getChildren().addAll(branding, title, new Separator(), searchPanel, slipGrid, btnReturn);

        Scene scene = new Scene(mainLayout, 700, 750);
        stage.setScene(scene);
        stage.setTitle("Woldiya University - Salary Enquiry");
        stage.show();
    }

    private void fetchRecordFromDatabase(String id, GridPane grid, VBox searchBox) {
        // MATCHED TO SALARYMANAGEMENT: Querying the processed 'payroll' table
        String sql = "SELECT fullName, present_days, leave_days, gross_salary, pension, tax, net_salary " +
                     "FROM payroll WHERE employee_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                grid.getChildren().clear(); 
                
                // Pulling pre-calculated data from the payroll record
                String name = rs.getString("fullName");
                int present = rs.getInt("present_days");
                int leave = rs.getInt("leave_days");
                double gross = rs.getDouble("gross_salary");
                double pension = rs.getDouble("pension");
                double tax = rs.getDouble("tax");
                double net = rs.getDouble("net_salary");

                // Layout display
                addSlipRow(grid, 0, "Employee Name:", name, "#34495E");
                addSlipRow(grid, 1, "Employee ID:", id, "#34495E");
                addSlipRow(grid, 2, "Days Present:", String.valueOf(present), "#34495E");
                addSlipRow(grid, 3, "Leave Days:", String.valueOf(leave), "#34495E");
                
                grid.add(new Separator(), 0, 4, 2, 1);
                
                addSlipRow(grid, 5, "Gross Salary:", String.format("%.2f ETB", gross), "#2980B9");
                addSlipRow(grid, 6, "Pension (7%):", String.format("-%.2f ETB", pension), "#E67E22");
                addSlipRow(grid, 7, "Income Tax:", String.format("-%.2f ETB", tax), "#C0392B");
                
                Label lblNet = new Label("NET PAYABLE:");
                lblNet.setStyle("-fx-font-weight: bold; -fx-font-size: 16px;");
                Label valNet = new Label(String.format("%.2f ETB", net));
                valNet.setStyle("-fx-font-weight: bold; -fx-font-size: 18px; -fx-text-fill: #27AE60;");
                grid.addRow(8, lblNet, valNet);

                grid.setVisible(true); 
                searchBox.setDisable(true); 
                
            } else {
                showAlert(Alert.AlertType.WARNING, "Not Processed", 
                          "No processed payroll record found for ID: " + id + ". Please contact HR.");
            }
        } catch (SQLException ex) {
            showAlert(Alert.AlertType.ERROR, "System Error", "Database Fetch Error: " + ex.getMessage());
        }
    }

    private void addSlipRow(GridPane gp, int row, String label, String value, String color) {
        Label lbl = new Label(label);
        lbl.setStyle("-fx-font-weight: bold; -fx-text-fill: #7F8C8D;");
        Label val = new Label(value);
        val.setStyle("-fx-font-weight: bold; -fx-text-fill: " + color + ";");
        gp.add(lbl, 0, row);
        gp.add(val, 1, row);
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type, content);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.showAndWait();
    }
}