package EMS;

import java.sql.*;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;


public class UserAccountManagementModule {
    private Stage stage;

    public UserAccountManagementModule(Stage stage) {
        this.stage = stage;
    }

    public void show() {
        VBox layout = new VBox(15);
        layout.setPadding(new Insets(25));
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-background-color: #F4F6F7;");

        Label header = new Label("ADMIN: ACCOUNT & ID SYNC");
        header.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #2C3E50;");

        // Input Fields
        TextField oldIdField = new TextField(); 
        oldIdField.setPromptText("Current Employee ID");
        
        TextField newIdField = new TextField(); 
        newIdField.setPromptText("New Employee ID");
        
        TextField confirmIdField = new TextField(); 
        confirmIdField.setPromptText("Confirm New Employee ID");

        Button btnUpdate = new Button("Update Account & Sync ID");
        btnUpdate.setStyle("-fx-background-color: #2980B9; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10;");
        btnUpdate.setMaxWidth(Double.MAX_VALUE);

        btnUpdate.setOnAction(e -> {
            String oldId = oldIdField.getText().trim();
            String newId = newIdField.getText().trim();
            String confirmId = confirmIdField.getText().trim();

            if (oldId.isEmpty() || newId.isEmpty() || confirmId.isEmpty()) {
                showAlert("Validation Error", "All ID fields are required.");
                return;
            }

            if (!newId.equals(confirmId)) {
                showAlert("Error", "The New ID and Confirm ID do not match!");
                return;
            }

            // Execute Database Sync
            if (syncDatabaseId(oldId, newId)) {
                // Update Local Dashboard Data
                updateLocalMemory(oldId, newId);
                
                showAlert("Success", "ID Synced successfully across all tables!");
                oldIdField.clear(); 
                newIdField.clear(); 
                confirmIdField.clear();
            }
        });

        Button btnBack = new Button("Back to Dashboard");
        btnBack.setStyle("-fx-background-color: #7F8C8D; -fx-text-fill: white;");
        btnBack.setOnAction(e -> new AdminDashboard(stage, "Admin").show());

        layout.getChildren().addAll(
            header, new Separator(), 
            new Label("Current ID:"), oldIdField, 
            new Label("New ID:"), newIdField, 
            new Label("Confirm New ID:"), confirmIdField,
            btnUpdate, btnBack
        );
        
        stage.setScene(new Scene(layout, 400, 550));
        stage.setTitle("EMS - Admin ID Management");
        stage.show();
    }

    /**
     * Updates the ID in every table.
     * Uses SET FOREIGN_KEY_CHECKS to allow the Primary Key to be updated 
     * without blocking the linked tables.
     */
    private boolean syncDatabaseId(String oldId, String newId) {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false); // Start Transaction

            try (Statement stmt = conn.createStatement()) {
                // 1. Disable Foreign Key Checks
                stmt.execute("SET FOREIGN_KEY_CHECKS = 0");

                // 2. Define tables and their respective ID column names
                String[] tables = {"employees", "attendance", "leavemanag", "payroll"};
                String[] columns = {"id", "employee_id", "employee_id", "employee_id"};

                for (int i = 0; i < tables.length; i++) {
                    String sql = "UPDATE " + tables[i] + " SET " + columns[i] + " = ? WHERE " + columns[i] + " = ?";
                    try (PreparedStatement ps = conn.prepareStatement(sql)) {
                        ps.setString(1, newId);
                        ps.setString(2, oldId);
                        ps.executeUpdate();
                    }
                }

                // 3. Re-enable Foreign Key Checks
                stmt.execute("SET FOREIGN_KEY_CHECKS = 1");
            }

            conn.commit(); 
            return true;

        } catch (SQLException ex) {
            if (conn != null) {
                try {
                    // Safety: re-enable keys even on failure
                    Statement failStmt = conn.createStatement();
                    failStmt.execute("SET FOREIGN_KEY_CHECKS = 1");
                    conn.rollback(); 
                } catch (SQLException e) { e.printStackTrace(); }
            }
            showAlert("Database Error", "Sync failed: " + ex.getMessage());
            return false;
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); conn.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
        }
    }

    /**
     * Updates the static lists so dashboards refresh without restarting.
     */
    private void updateLocalMemory(String oldId, String newId) {
        // Update Employee data
        Employee emp = EmployeeRecordsModule.getEmployeeById(oldId);
        if (emp != null) emp.setId(newId);

        // Update Attendance data
        ManageAttendance.AttendanceRecord att = ManageAttendance.getAttendanceById(oldId);
        if (att != null) {
            // Note: Ensure ManageAttendance.AttendanceRecord has setEmployeeId(String id)
            att.setEmployeeId(newId);
        }

        // Update Leave data
        for (LeaveData.LeaveRecord lr : LeaveData.allRequests) {
            if (lr.getId().equalsIgnoreCase(oldId)) {
                lr.setId(newId);
            }
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}