package EMS;

import java.sql.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

/**
 * STEP 5: LEAVE APPROVAL BOARD
 * Fixed: Full integration to receive data from LeaveRequest and sync Names from Database.
 */
public class LeaveManagement {
    private Stage stage;
    private TableView<LeaveData.LeaveRecord> table;

    public LeaveManagement(Stage stage) {
        this.stage = stage;
    }

    public void show() {
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_CENTER);
        layout.setStyle("-fx-background-color: #F4F6F7;");

        Label header = new Label("STEP 5: LEAVE APPROVAL BOARD");
        header.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #2C3E50;");

        // Use the shared data bridge list
        table = new TableView<>(LeaveData.allRequests);
        setupTable();
        
        // --- 1. Load existing records from DB 2. Sync Names for any new requests ---
        loadFromDatabase(); 
        loadNamesAndSyncDatabase(); 

        // --- BUTTONS ---
        Button btnApprove = new Button("APPROVE & SYNC");
        btnApprove.setStyle("-fx-background-color: #27AE60; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10 25;");

        Button btnReject = new Button("REJECT & PROCEED");
        btnReject.setStyle("-fx-background-color: #C0392B; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10 25;");

        Button btnPayroll = new Button("GO TO PAYROLL »");
        btnPayroll.setStyle("-fx-background-color: #E67E22; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10 25;");

        Button btnBack = new Button("Back to Dashboard");
        btnBack.setOnAction(e -> new AdminDashboard(stage, "Admin").show());

        // --- APPROVE LOGIC ---
        btnApprove.setOnAction(e -> {
            LeaveData.LeaveRecord selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                selected.setStatus("Approved");
                
                // Save status to DB
                saveToLeaveTable(selected);

                // Calculate cumulative sum for this employee
                int totalApprovedSum = 0;
                String empId = selected.getId();
                for (LeaveData.LeaveRecord lr : LeaveData.allRequests) {
                    if (lr.getId().equalsIgnoreCase(empId) && "Approved".equalsIgnoreCase(lr.getStatus())) {
                        totalApprovedSum += lr.getDays();
                    }
                }

                // Sync the total to the Attendance database
                ManageAttendance.AttendanceRecord att = ManageAttendance.getAttendanceById(empId);
                int currentPresent = (att != null) ? att.getDaysPresent() : 0;
                ManageAttendance.recordAttendanceToDatabase(empId, currentPresent, totalApprovedSum);

                table.refresh();
                showAlert("Success", "Leave Approved. Total days (" + totalApprovedSum + ") stored.");
            }
        });

        // --- REJECT LOGIC ---
        btnReject.setOnAction(e -> {
            LeaveData.LeaveRecord selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                selected.setStatus("Rejected");
                saveToLeaveTable(selected);
                table.refresh();
                showAlert("Rejected", "Status recorded. Opening Salary Management.");
                new SalaryManagement(stage).show();
            }
        });

        btnPayroll.setOnAction(e -> new SalaryManagement(stage).show());

        HBox controls = new HBox(15, btnApprove, btnReject, btnPayroll, btnBack);
        controls.setAlignment(Pos.CENTER);

        layout.getChildren().addAll(header, table, controls);

        stage.setScene(new Scene(layout, 1050, 600));
        stage.setTitle("EMS - Leave Management Board");
        stage.show();
    }

    /**
     * Loads everything from the 'leavemanag' table into the shared list.
     */
    private void loadFromDatabase() {
        LeaveData.allRequests.clear(); 
        String sql = "SELECT * FROM leavemanag";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                // Using the 4-argument constructor we added to LeaveData
                LeaveData.LeaveRecord record = new LeaveData.LeaveRecord(
                    rs.getString("employee_id"), 
                    rs.getString("fullName"), 
                    rs.getInt("requested_days"), 
                    rs.getString("status")
                );
                LeaveData.allRequests.add(record);
            }
        } catch (SQLException e) {
            System.err.println("DB Load Error: " + e.getMessage());
        }
    }

    /**
     * Saves the current status back to MySQL.
     */
    private void saveToLeaveTable(LeaveData.LeaveRecord lr) {
        String sql = "INSERT INTO leavemanag (employee_id, fullName, requested_days, status) VALUES (?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE status=VALUES(status), fullName=VALUES(fullName)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, lr.getId());
            pstmt.setString(2, lr.getFullName());
            pstmt.setInt(3, lr.getDays());
            pstmt.setString(4, lr.getStatus());
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void setupTable() {
        TableColumn<LeaveData.LeaveRecord, String> idCol = new TableColumn<>("Employee ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<LeaveData.LeaveRecord, String> nameCol = new TableColumn<>("Full Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("fullName"));

        TableColumn<LeaveData.LeaveRecord, Integer> daysCol = new TableColumn<>("Requested Days");
        daysCol.setCellValueFactory(new PropertyValueFactory<>("days"));

        TableColumn<LeaveData.LeaveRecord, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));

        table.getColumns().setAll(idCol, nameCol, daysCol, statusCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    /**
     * Fixes empty names: Matches IDs with the EmployeeRecordsModule names.
     */
    private void loadNamesAndSyncDatabase() {
        for (LeaveData.LeaveRecord lr : LeaveData.allRequests) {
            // If name is empty, fetch it from the master employee list
            if (lr.getFullName() == null || lr.getFullName().isEmpty()) {
                Employee emp = EmployeeRecordsModule.getEmployeeById(lr.getId());
                if (emp != null) {
                    lr.setFullName(emp.getName());
                }
            }
        }
        table.refresh();
    }

    private void showAlert(String title, String content) {
        new Alert(Alert.AlertType.INFORMATION, content).showAndWait();
    }
}