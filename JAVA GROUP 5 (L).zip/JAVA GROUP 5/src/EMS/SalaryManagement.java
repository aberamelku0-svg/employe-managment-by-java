package EMS;

import java.sql.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

/**
 * STEP 6: FINAL PAYROLL DASHBOARD
 * Updated Logic: Automatically sums all attendance entries for the same ID from the database.
 */
public class SalaryManagement {
    private Stage stage;
    public static ObservableList<SalaryRecord> processedSalaries = FXCollections.observableArrayList();

    public SalaryManagement(Stage stage) {
        this.stage = stage;
        loadFromDatabase(); 
    }

    public void show() {
        BorderPane layout = new BorderPane();
        layout.setPadding(new Insets(20));
        layout.setStyle("-fx-background-color: #FBFCFC;");

        VBox topArea = new VBox(15);
        Label title = new Label("STEP 6: FINAL PAYROLL DASHBOARD");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #2C3E50;");

        HBox controlBar = new HBox(15);
        controlBar.setAlignment(Pos.CENTER_LEFT);
        
        TextField idField = new TextField();
        idField.setPromptText("Enter Employee ID...");
        idField.setPrefWidth(250);

        Button btnCalculate = new Button("SUM & CALCULATE SALARY");
        btnCalculate.setStyle("-fx-background-color: #E67E22; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10 20;");

        controlBar.getChildren().addAll(new Label("Target ID:"), idField, btnCalculate);
        topArea.getChildren().addAll(title, new Separator(), controlBar);

        TableView<SalaryRecord> table = new TableView<>(processedSalaries);
        setupTableColumns(table);

        btnCalculate.setOnAction(e -> {
            String searchId = idField.getText().trim();
            
            Employee emp = EmployeeRecordsModule.getEmployeeById(searchId);

            if (emp != null) {
                // --- CRITICAL UPDATE: Summation Query ---
                // We pull the SUM of present and leave days directly from the database for this ID
                int totalPresent = 0;
                int totalLeave = 0;

                String sumSql = "SELECT SUM(present_days) as p_sum, SUM(leave_days) as l_sum " +
                                "FROM attendance WHERE employee_id = ?";

                try (Connection conn = DatabaseConnection.getConnection();
                     PreparedStatement pstmt = conn.prepareStatement(sumSql)) {
                    
                    pstmt.setString(1, searchId);
                    ResultSet rs = pstmt.executeQuery();

                    if (rs.next()) {
                        totalPresent = rs.getInt("p_sum");
                        totalLeave = rs.getInt("l_sum");
                    }
                } catch (SQLException ex) { ex.printStackTrace(); }

                int totalWorkDays = totalPresent + totalLeave;

                if (totalWorkDays > 22) {
                    new Alert(Alert.AlertType.ERROR, "ID " + searchId + " has " + totalWorkDays + 
                              " total days. This exceeds the monthly limit of 22.").show();
                } else if (totalWorkDays == 0) {
                    new Alert(Alert.AlertType.WARNING, "No attendance found for ID: " + searchId).show();
                } else {
                    // --- CALCULATION LOGIC (2026 Standards) ---
                    double dailyRate = emp.getBaseSalary() / 22.0; 
                    double grossSalary = dailyRate * totalWorkDays;
                    double pension = grossSalary * 0.07;
                    double taxableIncome = grossSalary - pension;

                    double tax = 0;
                    if (taxableIncome <= 2000) tax = 0;
                    else if (taxableIncome <= 4000) tax = (taxableIncome * 0.15) - 300;
                    else if (taxableIncome <= 7000) tax = (taxableIncome * 0.20) - 500;
                    else if (taxableIncome <= 10000) tax = (taxableIncome * 0.25) - 850;
                    else if (taxableIncome <= 14000) tax = (taxableIncome * 0.30) - 1350;
                    else tax = (taxableIncome * 0.35) - 2050;

                    double netSalary = taxableIncome - tax;

                    // Update UI and Database
                    recordSalaryToDatabase(searchId, emp.getName(), totalPresent, totalLeave, grossSalary, pension, tax, netSalary);
                    
                    processedSalaries.removeIf(r -> r.getId().equalsIgnoreCase(searchId));
                    processedSalaries.add(new SalaryRecord(searchId, emp.getName(), totalPresent, totalLeave, grossSalary, pension, tax, netSalary));
                    
                    new Alert(Alert.AlertType.INFORMATION, "Salary Summed and Processed for: " + emp.getName()).show();
                }
            } else {
                new Alert(Alert.AlertType.ERROR, "Employee ID not found in Records!").show();
            }
        });

        layout.setTop(topArea);
        layout.setCenter(table);
        
        Button btnBack = new Button("← BACK TO ADMIN DASHBOARD");
        btnBack.setOnAction(e -> new AdminDashboard(stage, "Admin").show());
        layout.setBottom(new HBox(btnBack));

        stage.setScene(new Scene(layout, 1200, 650));
        stage.show();
    }

    // recordSalaryToDatabase and setupTableColumns remain the same as previous full version...
    // (Ensure you include them to keep the code functional)

    private void recordSalaryToDatabase(String id, String name, int p, int l, double gross, double pen, double tax, double net) {
        String sql = "INSERT INTO payroll (employee_id, fullName, present_days, leave_days, gross_salary, pension, tax, net_salary) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE " +
                     "fullName=VALUES(fullName), present_days=VALUES(present_days), leave_days=VALUES(leave_days), " +
                     "gross_salary=VALUES(gross_salary), net_salary=VALUES(net_salary)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            pstmt.setString(2, name);
            pstmt.setInt(3, p);
            pstmt.setInt(4, l);
            pstmt.setDouble(5, gross);
            pstmt.setDouble(6, pen);
            pstmt.setDouble(7, tax);
            pstmt.setDouble(8, net);
            pstmt.executeUpdate();
        } catch (SQLException ex) { ex.printStackTrace(); }
    }

    private void loadFromDatabase() {
        processedSalaries.clear();
        String sql = "SELECT * FROM payroll";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                processedSalaries.add(new SalaryRecord(
                    rs.getString("employee_id"), rs.getString("fullName"),
                    rs.getInt("present_days"), rs.getInt("leave_days"),
                    rs.getDouble("gross_salary"), rs.getDouble("pension"),
                    rs.getDouble("tax"), rs.getDouble("net_salary")
                ));
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }

    private void setupTableColumns(TableView<SalaryRecord> table) {
        TableColumn<SalaryRecord, String> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        TableColumn<SalaryRecord, String> nameCol = new TableColumn<>("Full Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        TableColumn<SalaryRecord, Integer> pCol = new TableColumn<>("Present (Sum)");
        pCol.setCellValueFactory(new PropertyValueFactory<>("presentDays"));
        TableColumn<SalaryRecord, Integer> lCol = new TableColumn<>("Leave (Sum)");
        lCol.setCellValueFactory(new PropertyValueFactory<>("leaveDays"));
        TableColumn<SalaryRecord, Double> nCol = new TableColumn<>("Net Pay (ETB)");
        nCol.setCellValueFactory(new PropertyValueFactory<>("net"));
        table.getColumns().addAll(idCol, nameCol, pCol, lCol, nCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    public static class SalaryRecord {
        private String id, fullName;
        private int presentDays, leaveDays;
        private double gross, pension, tax, net;

        public SalaryRecord(String id, String name, int p, int l, double g, double pen, double t, double n) {
            this.id = id; this.fullName = name; this.presentDays = p; this.leaveDays = l;
            this.gross = format(g); this.pension = format(pen);
            this.tax = format(t); this.net = format(n);
        }
        private double format(double val) { return Math.round(val * 100.0) / 100.0; }
        public String getId() { return id; }
        public String getFullName() { return fullName; }
        public int getPresentDays() { return presentDays; }
        public int getLeaveDays() { return leaveDays; }
        public double getNet() { return net; }
    }
}